import React from 'react';
import logo from './logo.svg';
import './App.css';
import VideoConference from './components/VideoConference';

function App() {
  return (
    <div className="App">
      <VideoConference></VideoConference>
    </div>
  );
}

export default App;
